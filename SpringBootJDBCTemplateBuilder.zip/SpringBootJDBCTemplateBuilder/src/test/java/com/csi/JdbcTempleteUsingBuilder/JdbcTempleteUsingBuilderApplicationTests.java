package com.csi.JdbcTempleteUsingBuilder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcTempleteUsingBuilderApplicationTests {

	@Test
	void contextLoads() {
	}

}
