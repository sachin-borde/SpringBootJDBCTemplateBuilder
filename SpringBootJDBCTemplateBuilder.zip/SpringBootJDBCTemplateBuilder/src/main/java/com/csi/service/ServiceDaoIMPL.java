package com.csi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.csi.dao.ProductDaoIMPL;
import com.csi.model.Product;

@Service
public class ServiceDaoIMPL implements ServiceDao {
	
	@Autowired
	ProductDaoIMPL productDaoImpl;

	@Override
	public List<Product> getAllProductData() {
		// TODO Auto-generated method stub
		return productDaoImpl.getAllProductData();
	}

	@Override
	public void saveProductData(Product product) {
		// TODO Auto-generated method stub
		productDaoImpl.saveProductData(product);
	}

	@Override
	public void updateProductData(int prodId, Product product) {
		// TODO Auto-generated method stub
		productDaoImpl.updateProductData(prodId, product);
	}

	@Override
	public void deleteProductData(int prodId) {
		// TODO Auto-generated method stub
		productDaoImpl.deleteProductData(prodId);
	}
	

}
