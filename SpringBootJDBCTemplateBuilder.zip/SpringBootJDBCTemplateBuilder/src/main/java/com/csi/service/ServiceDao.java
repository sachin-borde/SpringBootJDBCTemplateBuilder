package com.csi.service;

import java.util.List;

import com.csi.model.Product;

public interface ServiceDao {
	
public List<Product> getAllProductData();
	
	public void saveProductData(Product product);
	
	public void updateProductData(int prodId,Product product);
	
	public void deleteProductData(int prodId);

}
