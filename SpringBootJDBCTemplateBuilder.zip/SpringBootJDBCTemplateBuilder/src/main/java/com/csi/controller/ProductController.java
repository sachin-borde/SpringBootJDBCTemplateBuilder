package com.csi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.csi.model.Product;
import com.csi.service.ServiceDao;

@RestController
@RequestMapping("/api")
public class ProductController {
	
	@Autowired
	ServiceDao serviceDao;
	
	@GetMapping("/getdata")
	public List<Product>getProducts(){
		return serviceDao.getAllProductData();
	}
	
	@PostMapping("/saveData")
	public String saveProductdata(@RequestBody Product product) {
		serviceDao.saveProductData(product);
		return "Data Save Sucessfully";
	}
	
	@PutMapping("/updatedata/{prodId}")
	public String updateProductData(@PathVariable("prodId") int ProdId,@RequestBody Product product) {
		serviceDao.updateProductData(ProdId, product);
		return "Data Updated";
	}
	
	@DeleteMapping("/deletedata/{prodId}")
	public String deleteProductData(@PathVariable("prodId") int prodId) {
		serviceDao.deleteProductData(prodId);
		return "Data Deleted";
	}

}
