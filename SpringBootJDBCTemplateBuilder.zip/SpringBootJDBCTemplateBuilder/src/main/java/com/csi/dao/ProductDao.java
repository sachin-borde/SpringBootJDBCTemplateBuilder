package com.csi.dao;

import java.util.List;

import com.csi.model.Product;

public interface ProductDao {
	
	public List<Product> getAllProductData();
	
	public void saveProductData(Product product);
	
	public void updateProductData(int prodId,Product product);
	
	public void deleteProductData(int prodId);
	}


