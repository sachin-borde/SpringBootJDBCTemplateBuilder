package com.csi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.csi.model.Product;

@Component
public class ProductDaoIMPL implements ProductDao {

	@Autowired
	JdbcTemplate jdbcTemplete;

	public static final String selectAllSQL = "select * from product";

	public static final String insertSQL = "insert into product (prodName,prodPrice)values(?,?)";

	public static final String updateSQL = "update product set prodName=?,prodPrice=? where prodId=?";

	public static final String deleteSQL = "delete from Product where prodId=?";

	public Product product(ResultSet rs, int numRow) throws SQLException {
		return Product.builder().prodId(rs.getInt(1)).prodName(rs.getString(2)).prodPrice(rs.getDouble(3)).build();
	}

	@Override
	public List<Product> getAllProductData() {
		return jdbcTemplete.query(selectAllSQL, this::product);
	}

	@Override
	public void saveProductData(Product product) {
		jdbcTemplete.update(insertSQL, product.getProdName(), product.getProdPrice());
	}

	@Override
	public void updateProductData(int prodId, Product product) {
		jdbcTemplete.update(updateSQL, product.getProdName(), product.getProdPrice(), prodId);
	}

	@Override
	public void deleteProductData(int prodId) {
		jdbcTemplete.update(deleteSQL, prodId);
	}
}
